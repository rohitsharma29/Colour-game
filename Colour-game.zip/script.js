function predict(color) {
  let adminColor = localStorage.getItem("adminColor");
  let result = adminColor ? adminColor : ["Red", "Green"][Math.floor(Math.random() * 2)];

  document.getElementById("result").innerText = 
    (color === result) 
      ? `🎉 You Win! Winning Color: ${result}` 
      : `❌ You Lose! Winning Color: ${result}`;
}
