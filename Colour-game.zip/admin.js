let adminPassword = "ff444ff444";

function login() {
  let pwd = document.getElementById("password").value;
  if (pwd === adminPassword) {
    document.getElementById("panel").style.display = "block";
  } else {
    alert("Wrong Password");
  }
}

function setWinningColor(color) {
  localStorage.setItem("adminColor", color);
  alert("Winning color set to " + color);
}
